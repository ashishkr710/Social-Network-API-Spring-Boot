package com.example.social;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialNetworkingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
