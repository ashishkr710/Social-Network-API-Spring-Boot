package com.example.social.location;

import org.springframework.data.repository.CrudRepository;

public interface LocationRepo extends CrudRepository<Location, String> {
	
}
